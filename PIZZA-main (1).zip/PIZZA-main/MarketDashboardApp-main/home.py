import streamlit as st
from PIL import Image
from inject_font import inject_custom_font

# Set page config first
st.set_page_config(page_title="MarketDashboard by AMPATE AS BORROWED FROM TTZ - Home", layout="wide")

# Inject custom font (Roboto or whatever you're using)
inject_custom_font()

# --- Title & Intro ---
st.title("📊 Welcome to MarketDashboard by AMPATE AS BORROWED FROM TTZ")

st.markdown("""
This app gives you a powerful lens into market structure and ETF dynamics, including:

### 🧠 OVERLAYORRRR 🔥
Your secret weapon. Find past time windows that closely resemble the current SPX pattern. Visualize how those setups evolved and overlay them for context.

---

Use the sidebar to navigate. Built for insights, speed, and sharing alpha with your crew.
""")
